import React,{useState, useEffect} from 'react'
import { Link } from 'react-router-dom'
import StudentServices from '../Services/StudentServices'

export const ListStudentComponent = () => {
    const [student, setStudent] = useState([])
    useEffect(() => {
        getAllStudent();

        
        
              
       }, [])

    const getAllStudent = () => {
        StudentServices.getAllStudent().then((response) => {
            setStudent(response.data)
            console.log(response.data);
        }).catch(error =>{
            console.log(error);
        })

    }
    
  const deleteStudent = (studentId) => {
      StudentServices.deleteStudent(studentId).then((response) =>{
          getAllStudent();

      }).catch(error =>{
          console.log(error);
      })
  }

  return (
    <div  className='container'>
        <h2 className = "text-center"> List Student</h2>
        <Link to = "/add-student" className = "btn btn-primary mb-2"> Add Students </Link>
        <table className="table table-bordered table-striped">
            <thead>
                <th> ID</th>
                <th> First Name</th>
                <th> Last Name</th>
                <th> Email Id</th>
                <th> Actions </th>
            </thead>
            <tbody>
                {
                    student.map(
                        student=>
                        <tr  key={student.id}>
                            <td> {student.id} </td>
                            <td> {student.firstName} </td>
                            <td> {student.lastName}</td>
                            <td> {student.emailId}</td>
                            <td>
                                <div>
                                <Link className='btn btn-info'  to={`/edit-student/${student.id}`}>Update</Link>
                                </div>

                                <div>
                                <button className='btn btn-danger' id="del"onClick={() => deleteStudent(student.id)}> Delete</button>
                                </div>
                            </td>
                            
                        </tr>

                    )
                }
            </tbody>
        </table>
       

    </div>
  )
}
