
import './App.css';
import {BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HeaderComponent from './components/HeaderComponent';
import { ListStudentComponent } from './components/ListStudentComponent';
import FooterComponent from './components/FooterComponent';
import AddStudent from './components/AddStudent';

function App() {
  return (
    <div>
   <HeaderComponent />
     <Router>
   
      <div className='container'>
        <Routes>
          <Route exact path = "/" element= {<ListStudentComponent/>}></Route>
          <Route path = "/students" element= {<ListStudentComponent/>}></Route>
          <Route path = "/add-student" element= {<AddStudent/>}></Route>
          <Route path = "/edit-student/:id" element = {<AddStudent/>}></Route>
        </Routes>
     
      </div>
    
      </Router>
      <FooterComponent />
    </div>
  ); 
}

export default App;
